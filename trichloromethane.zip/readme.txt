████████╗██████╗ ██╗ ██████╗██╗  ██╗██╗      ██████╗ ██████╗  ██████╗ ███╗   ███╗███████╗████████╗██╗  ██╗ █████╗ ███╗   ██╗███████╗   ███████╗██╗  ██╗███████╗
╚══██╔══╝██╔══██╗██║██╔════╝██║  ██║██║     ██╔═══██╗██╔══██╗██╔═══██╗████╗ ████║██╔════╝╚══██╔══╝██║  ██║██╔══██╗████╗  ██║██╔════╝   ██╔════╝╚██╗██╔╝██╔════╝
   ██║   ██████╔╝██║██║     ███████║██║     ██║   ██║██████╔╝██║   ██║██╔████╔██║█████╗     ██║   ███████║███████║██╔██╗ ██║█████╗     █████╗   ╚███╔╝ █████╗  
   ██║   ██╔══██╗██║██║     ██╔══██║██║     ██║   ██║██╔══██╗██║   ██║██║╚██╔╝██║██╔══╝     ██║   ██╔══██║██╔══██║██║╚██╗██║██╔══╝     ██╔══╝   ██╔██╗ ██╔══╝  
   ██║   ██║  ██║██║╚██████╗██║  ██║███████╗╚██████╔╝██║  ██║╚██████╔╝██║ ╚═╝ ██║███████╗   ██║   ██║  ██║██║  ██║██║ ╚████║███████╗██╗███████╗██╔╝ ██╗███████╗
   ╚═╝   ╚═╝  ╚═╝╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝(aka Chloroform.exe)
                                                                                                                                                               
Malware name: trichloromethane
type: GDI-Trojan.Win32
Damage rate: Destructive (for non-safety version), very low (ONLY FOR SAFETY VERSION)
Made in: C++
Creator: pankoza
Creation date: 9 October 2022

This is very dangerous for the non-safety version! It will destroy this computer by overwriting MBR and disable keyboard and mouse input
The Creator is NOT responsible for any damages!

credits to Void_/GetMbr for the Hue function
credits to EthernalVortex for PRGBQUAD